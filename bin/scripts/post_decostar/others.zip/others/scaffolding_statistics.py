__author__="Cedric Chauve"
__email__="cedric.chauve@sfu.ca"
__date__="November 22, 2016"

import sys
import os
import numpy as np
import math

USAGE="python scaffolding_statistics.py <scaffolding files prefix> <output file>\n"
USAGE+="  PREF=input file prefix\n"
USAGE+="  assumption: files PREF_disc, PREF_kept, PREF_obs_scaffolds and PREF_scaffolds exist"
USAGE+="  and represent respectively discarded adjacencies, kept adjaencies, scaffolds with observed adjacencies, improved scaffolds\n"

# Adjacencies format:
# species gene1 gene2 orientation1 orientation2 prior_score posterior_score scaffold_id

# ----------------------------------------------------------------------------------------------------------
# DATA STRUCTURE FOR ADJACENCY: (species,gene_name,extremity('h','t'),gene_name,extremity,prior,posterior)
OBSERVED=1.0     # Default score for observed adjacencies (true value to be read as a parameter)

def adj_species(adj):
    return(adj[0])
def adj_gene1(adj):
    return(adj[1])
def adj_gene2(adj):
    return(adj[3])
def adj_ext1(adj):
    return(adj[2])
def adj_ext2(adj):
    return(adj[4])
def adj_prior(adj):
    return(adj[5])
def adj_posterior(adj):
    return(adj[6])
def adj_observed(adj): # True/False
    return(adj[5]==OBSERVED)

# Translating the orientation of the contigs into the corresponding gene extremity involved in an adjacency
GENE1_ORIENT2EXT={'-':'t','+':'h','?':'?'}
GENE2_ORIENT2EXT={'-':'h','+':'t','?':'?'}
GENE1_EXT2ORIENT={'t':'-','h':'+','?':'?'}
GENE2_EXT2ORIENT={'h':'-','t':'+','?':'?'}

# ----------------------------------------------------------------------------------------------------------
# Reading the adjacencies in the DeCo* format 
# file_stream = opened adjacencies file
# output = adj_list, list of adjacencies
# updates the GENES_LIST and MAX_WEIGHT global variables
def read_adjacencies(file_stream,species):
    res_adj_list=[]   # List of adjacencies, returned
    for adj in file_stream:
        if adj[0]!="#": # "#" is used for comments
            adj1=adj.rstrip().split()
            if adj1[0]==species:
                assert(float(adj1[5])<=1.0), "ERROR: prior score greater than 1"
                assert(float(adj1[6])<=1.0), "ERROR: posterior score greater than 1"
                res_adj_list.append((adj1[0],adj1[1],GENE1_ORIENT2EXT[adj1[3]],adj1[2],GENE2_ORIENT2EXT[adj1[4]],float(adj1[5]),float(adj1[6])))
    return(res_adj_list)

# ----------------------------------------------------------------------------------------------------------
# Extracting besst and deco (that are not observed) adjacencies from a set of adjacencies
def adjs_extract_besst_deco(adjs):
    besst=[]
    deco=[]
    for adj in adjs:
        if not adj_observed(adj):
            if adj_prior(adj)>0:
                besst.append(adj)
            if adj_posterior(adj)>0:
                deco.append(adj)
    return((besst,deco))

# ----------------------------------------------------------------------------------------------------------
# Creating two numpy arrays with the adjacencies prior and posterior scores scores
def adjs_scores(adjs,keep_obs):
    adjs_prior=[]
    adjs_posterior=[]
    for adj in adjs:
        if (not adj_observed(adj)) or keep_obs:
            adjs_prior.append(adj_prior(adj))
            adjs_posterior.append(adj_posterior(adj))
    return((np.sort(np.array(adjs_prior)),np.sort(np.array(adjs_posterior))))

# ----------------------------------------------------------------------------------------------------------
# Number of observed and BESST and DeCo*adjacencies
def adjs_nb_obs(adjs):
    nb_obs=0
    for adj in adjs:
        if adj_observed(adj)==True:
            nb_obs+=1
    return(nb_obs)

# ----------------------------------------------------------------------------------------------------------
# DATA STRUCTURE FOR SCAFFOLD: (species,id,list of (gene,orientation))
def scf_species(scf):
    return(scf[0])
def scf_id(scf):
    return(scf[1])
def scf_genes(scf):
    return(scf[2])
def scf_gene_name(gene):
    return(gene[0])
def scf_gene_sign(gene):
    return(gene[1])

# ----------------------------------------------------------------------------------------------------------
# Reading the adjacencies in the DeCo* format 
# file_stream = opened adjacencies file
# output = adj_list, list of adjacencies
# updates the GENES_LIST and MAX_WEIGHT global variables
def read_scaffolds(file_stream,species):
    res_scf_list=[]
    current_scf=""
    for gene in file_stream:
        if gene[0]!="#": # "#" is used for comments
            gene1=gene.rstrip().split()
            if gene1[0]==species:
                scf=gene1[1]                
                if scf!=current_scf: # Special case, we start a new scaffold
                    if current_scf!="": # This is not the first scaffold: we record the current one
                        res_scf_list.append((species,current_scf,genes_list))
                    genes_list=[]
                    current_scf=scf
                genes_list.append((gene1[2],gene1[3]))
    res_scf_list.append((species,current_scf,genes_list)) # Last scaffold
    return(res_scf_list)

# ----------------------------------------------------------------------------------------------------------
# Creating a numpy array with the scaffolds lengths
def scfs_length(scfs):
    scfs_lg=[]
    for scf in scfs:
        if scf[0]!="#":
            scfs_lg.append(len(scf_genes(scf)))
    return(np.sort(np.array(scfs_lg)))

# ----------------------------------------------------------------------------------------------------------
# Computing the NXX value for a set of scaffolds
def scfs_NXX(np_scfs_lg,xx):
    nb_genes_all=np.sum(np_scfs_lg)
    nb_genes_xx=math.ceil((float(nb_genes_all))*(float(xx))/100.0)
    nb_genes_current=0
    i=len(np_scfs_lg)-1
    while nb_genes_current<nb_genes_xx:
        nb_genes_current+=np_scfs_lg[i]
        i-=1
    return(np_scfs_lg[i+1])

# ----------------------------------------------------------------------------------------------------------
# Number of genes
def scfs_nb_genes(np_scfs_lg):
    return(np.sum(np_scfs_lg))
    
# ----------------------------------------------------------------------------------------------------------
# Reading species from scaffolds file
def read_species(scfs):
    ALL_SPECIES_AUX={}
    for scf in scfs:
        if scf[0]!="#": # "#" is used for comments
            scf1 = scf.rstrip().split()
            species=scf1[0]
            ALL_SPECIES_AUX[species]=1
    return(sorted(list(ALL_SPECIES_AUX.keys())))

# ----------------------------------------------------------------------------------------------------------
# Printing a histogram
def print_histogram(hist):
    res=""
    nb_bins=len(hist[0])
    for i in range(0,nb_bins):
        res+="["+str(hist[1][i])+","+str(hist[0][i])+"];"
    return(res)

# Printing a histogram
def print_histogram_shifted(hist,offset):
    res=""
    nb_bins=len(hist[0])
    for i in range(1,nb_bins+1):
        res+="["+str(hist[1][i]-offset)+","+str(hist[0][i-1])+"];"
    return(res)

# ----------------------------------------------------------------------------------------------------------
# Main

# Parameters
PREF=sys.argv[1]
ADJS_DISC_STREAM=open(PREF+"_disc","r").readlines()
ADJS_KEPT_STREAM=open(PREF+"_kept","r").readlines()
SCFS_OBS_STREAM=open(PREF+"_obs_scaffolds","r").readlines()
SCFS_NEW_STREAM=open(PREF+"_scaffolds","r").readlines()

# Parameters of the statistics
SCFS_LG_HIST_BINS=[0,11,51,101,501,1001,2001,5001]   # Bins of the histograms for the scaffold length distribution
SCFS_LG_HIST_NB_BINS=len(SCFS_LG_HIST_BINS)   # Number of bins of the histograms for the scaffold length distribution
SCFS_NXX_RANGE=[50,60,70,80,90]               # NXX values
ADJS_SCORES_HIST_BINS=[0.0,0.5,0.6,0.7,0.8,0.9,0.95,0.99,1.0] # Bins for adjacencies scores distributions
ADJS_SCORES_HIST_NB_BINS=len(ADJS_SCORES_HIST_BINS)                # Number of bins of the adj score histograms

# File preamble
OUTPUT=open(sys.argv[2],"w")
OUTPUT.write("#"+''.join([arg+" " for arg in sys.argv])+"\n")
OUTPUT.write("#Each line starts with a species number\n")
OUTPUT.write("#Statistics ADJSNB = number of observed, BESST, DeCo* adjacencies\n")
OUTPUT.write("#Remark: an observed adjacency is an adjacency with prior score=1.0\n")
OUTPUT.write("#Remark: a DeCo* adjacency is an adjacency with prior score<1.0 and posterior score>0.0\n")
OUTPUT.write("#Remark: a BESST adjacency is an adjacency with prior score>0.0 and prior score<1.0\n")
OUTPUT.write("#Statistics SCFNB = number of contigs/scaffolds before and after scaffolding\n")
OUTPUT.write("#Statistics ISCFLG = improved scaffolds length (in number of genes)\n")
OUTPUT.write("#Statistics OSCFLG = observed scaffolds length (in number of genes)\n")
OUTPUT.write("#Statistics NXX = Number of genes of scaffolds required to cumulate XX% of all genes\n")
OUTPUT.write("#Statistics DISCPRIOR = Prior score of discarded adjacencies\n")
OUTPUT.write("#Statistics DISCPOST  = Posterior score of discarded adjacencies\n")
OUTPUT.write("#Statistics KEPTPRIOR = Prior score of kept adjacencies\n")
OUTPUT.write("#Statistics KEPTPOST  = Posterior score of kept adjacencies\n")
#OUTPUT.write("#Statistics APRIOR = Prior score of all adjacencies\n")
#OUTPUT.write("#Statistics APOST  = Posterior score of all adjacencies\n")
OUTPUT.write("#Statistics DECOPRIOR = Prior score of all DeCo* adjacencies\n")
OUTPUT.write("#Statistics DECOPOST  = Posterior score of all DeCo* adjacencies\n")
OUTPUT.write("#Statistics BESSTPRIOR = Prior score of all BESST adjacencies\n")
OUTPUT.write("#Statistics BESSTPOST  = Posterior score of all BESST adjacencies\n")

# Reading all species from the observed scaffolds file name
ALL_SPECIES=read_species(SCFS_OBS_STREAM)

# Main loop
for species in ALL_SPECIES:
    # Reading adjacencies and scaffolds for the current species
    ADJS_DISC=read_adjacencies(ADJS_DISC_STREAM,species)
    ADJS_KEPT=read_adjacencies(ADJS_KEPT_STREAM,species)
    SCFS_OBS=read_scaffolds(SCFS_OBS_STREAM,species)
    SCFS_NEW=read_scaffolds(SCFS_NEW_STREAM,species)

    # TO DO: have a BESST adjacencies category and llok iinto which ones are kept and discarded.
    nb_obs1=adjs_nb_obs(ADJS_DISC)
    nb_obs2=adjs_nb_obs(ADJS_KEPT)
    (BESST_DISC,DECO_DISC)=adjs_extract_besst_deco(ADJS_DISC)
    (BESST_KEPT,DECO_KEPT)=adjs_extract_besst_deco(ADJS_KEPT)
    nb_besst1=len(BESST_DISC)
    nb_besst2=len(BESST_KEPT)
    nb_scaf1=len(DECO_DISC)
    nb_scaf2=len(DECO_KEPT)
    
    # Number of adjacencies
    OUTPUT.write(species+"\tADJSNB\tobserved="+str(nb_obs1+nb_obs2)+","+str(nb_obs2))
    OUTPUT.write("\tBESST="+str(nb_besst1+nb_besst2)+","+str(nb_besst2))
    OUTPUT.write("\tDeCo*="+str(nb_scaf1+nb_scaf2)+","+str(nb_scaf2)+"\n")

    # Number of scaffolds
    OUTPUT.write(species+"\tSCFNB\tbefore="+str(len(SCFS_OBS))+" after="+str(len(SCFS_NEW))+"\n")

    # Statistics on scaffolds lengths (in number of genes)
    SCFS_NEW_LG=scfs_length(SCFS_NEW) # Sorted array of scaffolds lengths 
    SCFS_NEW_LG_HIST=np.histogram(SCFS_NEW_LG,bins=SCFS_LG_HIST_BINS) # Histogram
    SCFS_NEW_LG_MEAN=format(np.mean(SCFS_NEW_LG),'.2f')               # Mean length
    OUTPUT.write(species+"\tISCFLG\tmean="+str(SCFS_NEW_LG_MEAN)+"\thistogram="+print_histogram_shifted(SCFS_NEW_LG_HIST,1)+"\n")
    SCFS_OBS_LG=scfs_length(SCFS_OBS)
    if SCFS_OBS_LG[len(SCFS_OBS_LG)-1]!=1: # Extant species
        SCFS_OBS_LG_HIST=np.histogram(SCFS_OBS_LG,bins=SCFS_LG_HIST_BINS) # Histogram
        SCFS_OBS_LG_MEAN=format(np.mean(SCFS_OBS_LG),'.2f')               # Mean length
        OUTPUT.write(species+"\tOSCFLG\tmean="+str(SCFS_OBS_LG_MEAN)+"\thistogram="+print_histogram_shifted(SCFS_OBS_LG_HIST,1)+"\n")       
    else:
        OUTPUT.write(species+"\tOSCFLG\tmean=NA\thistogram=NA\n")
        
    # Statistics NXX
    SCFS_NB_GENES=scfs_nb_genes(SCFS_NEW_LG)
    OUTPUT.write(species+"\tNXX\tnb_genes="+str(SCFS_NB_GENES)+"\tvalues="+''.join(["["+str(XX)+","+str(scfs_NXX(SCFS_NEW_LG,XX))+"]" for XX in SCFS_NXX_RANGE])+"\n")

    # Adjacencies scores
    (ADJS_KEPT_SCORES_PRIOR,ADJS_KEPT_SCORES_POSTERIOR)=adjs_scores(ADJS_KEPT,False)
    (ADJS_DISC_SCORES_PRIOR,ADJS_DISC_SCORES_POSTERIOR)=adjs_scores(ADJS_DISC,False)
    (DECO_KEPT_SCORES_PRIOR,DECO_KEPT_SCORES_POSTERIOR)=adjs_scores(DECO_KEPT,False)
    (DECO_DISC_SCORES_PRIOR,DECO_DISC_SCORES_POSTERIOR)=adjs_scores(DECO_DISC,False)
    (BESST_KEPT_SCORES_PRIOR,BESST_KEPT_SCORES_POSTERIOR)=adjs_scores(BESST_KEPT,False)
    (BESST_DISC_SCORES_PRIOR,BESST_DISC_SCORES_POSTERIOR)=adjs_scores(BESST_DISC,False)
    #ADJS_ALL_SCORES_PRIOR     = np.array(sorted(list(ADJS_KEPT_SCORES_PRIOR)+list(ADJS_DISC_SCORES_PRIOR)))
    #ADJS_ALL_SCORES_POSTERIOR = np.array(sorted(list(ADJS_KEPT_SCORES_POSTERIOR)+list(ADJS_DISC_SCORES_POSTERIOR)))
    ADJS_DECO_SCORES_PRIOR     = np.array(sorted(list(DECO_KEPT_SCORES_PRIOR)+list(DECO_DISC_SCORES_PRIOR)))
    ADJS_DECO_SCORES_POSTERIOR = np.array(sorted(list(DECO_KEPT_SCORES_POSTERIOR)+list(DECO_DISC_SCORES_POSTERIOR)))    
    ADJS_BESST_SCORES_PRIOR     = np.array(sorted(list(BESST_KEPT_SCORES_PRIOR)+list(BESST_DISC_SCORES_PRIOR)))
    ADJS_BESST_SCORES_POSTERIOR = np.array(sorted(list(BESST_KEPT_SCORES_POSTERIOR)+list(BESST_DISC_SCORES_POSTERIOR)))    
    
    ADJS_KEPT_SCORES_PRIOR_HIST     = np.histogram(ADJS_KEPT_SCORES_PRIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_KEPT_SCORES_POSTERIOR_HIST = np.histogram(ADJS_KEPT_SCORES_POSTERIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_DISC_SCORES_PRIOR_HIST     = np.histogram(ADJS_DISC_SCORES_PRIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_DISC_SCORES_POSTERIOR_HIST = np.histogram(ADJS_DISC_SCORES_POSTERIOR,bins=ADJS_SCORES_HIST_BINS)
    #ADJS_ALL_SCORES_PRIOR_HIST     = np.histogram(ADJS_ALL_SCORES_PRIOR,bins=ADJS_SCORES_HIST_BINS)
    #ADJS_ALL_SCORES_POSTERIOR_HIST = np.histogram(ADJS_ALL_SCORES_POSTERIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_DECO_SCORES_PRIOR_HIST     = np.histogram(ADJS_DECO_SCORES_PRIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_DECO_SCORES_POSTERIOR_HIST = np.histogram(ADJS_DECO_SCORES_POSTERIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_BESST_SCORES_PRIOR_HIST     = np.histogram(ADJS_BESST_SCORES_PRIOR,bins=ADJS_SCORES_HIST_BINS)
    ADJS_BESST_SCORES_POSTERIOR_HIST = np.histogram(ADJS_BESST_SCORES_POSTERIOR,bins=ADJS_SCORES_HIST_BINS)        

    #OUTPUT.write(species+"\tAPRIOR\thistogram="+print_histogram_shifted(ADJS_ALL_SCORES_PRIOR_HIST,0)+"\n")
    #OUTPUT.write(species+"\tAPOST\thistogram="+print_histogram_shifted(ADJS_ALL_SCORES_POSTERIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tKEPTPRIOR\thistogram="+print_histogram_shifted(ADJS_KEPT_SCORES_PRIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tKEPTPOST\thistogram="+print_histogram_shifted(ADJS_KEPT_SCORES_POSTERIOR_HIST,0)+"\n") 
    OUTPUT.write(species+"\tDISCPRIOR\thistogram="+print_histogram_shifted(ADJS_DISC_SCORES_PRIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tDISCPOST\thistogram="+print_histogram_shifted(ADJS_DISC_SCORES_POSTERIOR_HIST,0)+"\n") 
    OUTPUT.write(species+"\tDECOPRIOR\thistogram="+print_histogram_shifted(ADJS_DECO_SCORES_PRIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tDECOPOST\thistogram="+print_histogram_shifted(ADJS_DECO_SCORES_POSTERIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tBESSTPRIOR\thistogram="+print_histogram_shifted(ADJS_BESST_SCORES_PRIOR_HIST,0)+"\n")
    OUTPUT.write(species+"\tBESSTPOST\thistogram="+print_histogram_shifted(ADJS_BESST_SCORES_POSTERIOR_HIST,0)+"\n")
